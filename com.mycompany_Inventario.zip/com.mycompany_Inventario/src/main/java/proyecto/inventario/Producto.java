
package proyecto.inventario;

import proyecto.inventario.*;

public class Producto {
 
 String nombreProducto;
    String id;

    public Producto(String nombreProducto, String id) {
        this.nombreProducto = nombreProducto;
        this.id = id;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public String getId() {
        return id;
    }

    public void setNombreProducto(String nombreProducto) {
        this.nombreProducto = nombreProducto;
    }

    public void setId(String id) {
        this.id = id;
    }   
    
}
